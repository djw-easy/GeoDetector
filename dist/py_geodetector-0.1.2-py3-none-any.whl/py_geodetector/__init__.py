from .geodetector import GeoDetector, load_example_data
